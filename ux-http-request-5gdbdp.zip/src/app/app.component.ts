import { Component } from '@angular/core';
import { ServerService } from './appServices/server.service';
import { Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  constructor(private serverService : ServerService ) { }
  dataTitle = this.serverService.getDataTitle();
  products = [
    {
      id: 'p1',
      name:'Laptop',
      price: 45000
    },
    {
      id: 'p2',
      name:'Mobile',
      price: 8500
    },
    {
      id: 'p3',
      name:'Laptop',
      price: 45000
    },
    {
      id: 'p4',
      name:'Mobile',
      price: 8500
    },
  ]

  onAddProduct(id, name, price){
    this.products.push({
      id: id.value,
      name:name.value,
      price: price.value
    })
  }
  onSaveProduct(){
    this.serverService.addProducts(this.products)
      .subscribe(
        (response) => console.log(response),
        (err) => console.log(err) 
      )
  }
  onFetchProduct(){
    this.serverService.fetchProducts()
      .subscribe(
        (response:Response) => {
          this.products = [];
          const data = response.json();
          console.log(data);
          this.products = data;
        },
        (err) => console.log(err)
      )
  }
  onDeleteProduct(id){
    // this.serverService.deleteProducts(id);
    console.log(id)
    this.products.splice(id,1);
    this.onSaveProduct();
    //  setTimeout(() => {
    //   console.log('fetched')
      // this.onFetchProduct()
    //   }, 1000);
  }
}
