import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
// import { HttpClient, HttpClientModule } from '@angular/common/http';


import { AlertModule } from 'ngx-bootstrap';
import { ServerService } from './appServices/server.service'; 

@NgModule({
  imports:      [
     BrowserModule, 
    //  HttpClient, 
    //  HttpClientModule,
    HttpClientModule,
    HttpModule,
     FormsModule,
     AlertModule.forRoot() 
    ],
  declarations: [ AppComponent ],
  bootstrap:    [ AppComponent ],
  providers: [ServerService]
})
export class AppModule { }
