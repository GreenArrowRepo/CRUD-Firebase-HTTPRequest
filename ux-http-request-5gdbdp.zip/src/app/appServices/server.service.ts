import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Http, Headers } from '@angular/http';
import { Response } from '@angular/http';
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/retry';

@Injectable()
export class ServerService {

  constructor(private http :Http) { }
  url ='https://ux-datastorage.firebaseio.com/products.json';
  id:number;
  private headers = new Headers({'Content-Type':'application/json'});

  addProducts(products:any[]){
    // return this.http.post(this.url, products);

    return this.http.put(this.url, products);
  }
  fetchProducts(){
   return this.http.get(this.url)
    .catch(
      (err:Response) => {
        // console.log(err);
        // return Observable.throw(err)
        return Observable.throw('Something Wrong')
      }
    ); 
  }
  getDataTitle(){
    return this.http.get('https://ux-datastorage.firebaseio.com/dataTitle.json')
      .map(
        (res:Response) =>{
          return res.json()
          console.log(res)
      }
      )
  }
  deleteProducts(id){
    if(confirm("Are you sure")){
      // const proUrl = this.url+'/'+ id;
      const proUrl = 'https://ux-datastorage.firebaseio.com/products/'+id+'.json';
      // const proUrl = 'https://ux-datastorage.firebaseio.com/products/2.json';
      console.log(proUrl)
      return this.http.delete(proUrl, {headers: this.headers}).toPromise()
      // return this.http.delete(proUrl).toPromise()
        .then( ()=>{ 
            // setTimeout(() => {
            //   console.log('fetched')
            //   this.fetchProducts()
            // }, 1000);
        })
        .catch(
          (err:Response) =>{
            console.log(err)
          }
        )
    }
  }

}